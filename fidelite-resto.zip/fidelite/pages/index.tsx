import { useState } from 'react'
import { useRouter } from 'next/router'
import Head from 'next/head'
import { supabase } from '../lib/supabase'

export default function Inscription() {
  const router = useRouter()
  const [prenom, setPrenom] = useState('')
  const [telephone, setTelephone] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    const tel = telephone.replace(/\s/g, '')

    // Vérifie si le client existe déjà
    const { data: existing } = await supabase
      .from('clients')
      .select('id')
      .eq('telephone', tel)
      .single()

    if (existing) {
      // Client déjà inscrit → redirige vers sa carte
      router.push(`/carte/${existing.id}`)
      return
    }

    // Crée le nouveau client
    const { data, error: err } = await supabase
      .from('clients')
      .insert({ prenom, telephone: tel, points: 0 })
      .select('id')
      .single()

    if (err) {
      setError('Une erreur est survenue. Réessaie.')
      setLoading(false)
      return
    }

    router.push(`/carte/${data.id}`)
  }

  return (
    <>
      <Head>
        <title>Carte Fidélité</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#1D9E75" />
      </Head>
      <div className="app">
        <div className="inscription-wrap">
          <div className="inscription-logo">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <path d="M16 4C9.37 4 4 9.37 4 16s5.37 12 12 12 12-5.37 12-12S22.63 4 16 4zm0 6a3 3 0 110 6 3 3 0 010-6zm0 17a9 9 0 01-7-3.35C9.03 21.9 12.28 21 16 21s6.97.9 7 2.65A9 9 0 0116 27z" fill="white"/>
            </svg>
          </div>
          <h1 className="inscription-title">Rejoins le programme fidélité</h1>
          <p className="inscription-sub">Cumule des points à chaque commande et profite de réductions exclusives.</p>

          {error && <div className="feedback error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Ton prénom</label>
              <input
                className="form-input"
                type="text"
                placeholder="Ex: Thomas"
                value={prenom}
                onChange={e => setPrenom(e.target.value)}
                required
              />
            </div>
            <div className="form-group">
              <label className="form-label">Ton numéro de téléphone</label>
              <input
                className="form-input"
                type="tel"
                placeholder="06 12 34 56 78"
                value={telephone}
                onChange={e => setTelephone(e.target.value)}
                required
              />
            </div>
            <button
              className="btn btn-primary"
              type="submit"
              disabled={loading}
              style={{ marginTop: 8 }}
            >
              {loading ? 'Création en cours...' : 'Créer ma carte →'}
            </button>
          </form>
        </div>
      </div>
    </>
  )
}
